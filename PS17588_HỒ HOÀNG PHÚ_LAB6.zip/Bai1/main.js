function fout(){
	document.getElementById('image').src = "img/1.jpg";
}
function fover(){
	document.getElementById('image').src = "img/3.jpg";
}