var hoten = "Hồ Hoàng Phú";
var msv   = "PS17588";
var ns    = "16/09/2002";